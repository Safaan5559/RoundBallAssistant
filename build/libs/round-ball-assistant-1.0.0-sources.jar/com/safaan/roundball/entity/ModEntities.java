package com.safaan.roundball.entity;

import com.safaan.roundball.RoundBallAssistant;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_1621;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_4048;
import net.minecraft.class_7923;

public final class ModEntities {
    private ModEntities() {}

    public static final class_1299<RoundBallEntity> ROUND_BALL = class_2378.method_10230(
            class_7923.field_41177,
            class_2960.method_60655(RoundBallAssistant.MOD_ID, "round_ball"),
            FabricEntityTypeBuilder.create(class_1311.field_6294, RoundBallEntity::new)
                    .dimensions(class_4048.method_18385(0.65f, 0.65f))
                    .trackRangeBlocks(32)
                    .trackedUpdateRate(3)
                    .build()
    );

    public static void initialize() {
        FabricDefaultAttributeRegistry.register(ROUND_BALL, class_1621.method_26828());
        RoundBallAssistant.LOGGER.info("Registered Round Ball entity and attributes");
    }
}
