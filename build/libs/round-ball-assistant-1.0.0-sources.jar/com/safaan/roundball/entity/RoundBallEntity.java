package com.safaan.roundball.entity;

import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1361;
import net.minecraft.class_1588;
import net.minecraft.class_1621;
import net.minecraft.class_1657;
import net.minecraft.class_1937;

/** A small, persistent assistant ball. Its AI is intentionally non-hostile by default. */
public final class RoundBallEntity extends class_1621 {
    private class_1657 controller;

    public RoundBallEntity(class_1299<? extends class_1621> type, class_1937 world) {
        super(type, world);
        method_7161(1, true);
        method_5971();
    }

    @Override
    protected void method_5959() {
        field_6201.method_6277(8, new class_1361(this, class_1657.class, 10.0f));
    }

    @Override
    protected boolean method_7163() { return false; }

    public void setController(class_1657 player) { controller = player; }
    public class_1657 getController() { return controller; }

    public void followController() {
        if (controller == null || !controller.method_5805()) return;
        double distance = method_5739(controller);
        if (distance > 3.0) method_5942().method_6335(controller, distance > 12 ? 1.25 : 1.0);
        method_5988().method_6226(controller, 30.0f, 30.0f);
    }

    public void requestTarget(class_1309 target) {
        // The core assistant never chooses a target automatically. A future action provider
        // may explicitly request a target after the player asks for it.
        if (target != null && target.method_5805()) method_5980(target);
    }

    public void attackNearestHostile() {
        class_1309 nearest = method_37908().method_8390(class_1309.class, method_5829().method_1014(16.0),
                entity -> entity instanceof class_1588 && entity.method_5805()).stream()
                .min((first, second) -> Double.compare(method_5858(first), method_5858(second)))
                .orElse(null);
        requestTarget(nearest);
    }

    @Override
    public void method_5773() {
        super.method_5773();
        if (!method_37908().field_9236) followController();
    }

    @Override public boolean method_5974(double distanceSquared) { return false; }
    @Override public boolean method_27071() { return false; }
}
