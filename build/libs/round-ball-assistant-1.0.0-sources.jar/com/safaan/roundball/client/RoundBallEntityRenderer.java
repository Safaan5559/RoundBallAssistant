package com.safaan.roundball.client;

import com.safaan.roundball.RoundBallAssistant;
import net.minecraft.class_1621;
import net.minecraft.class_2960;
import net.minecraft.class_5617;
import net.minecraft.class_945;

/** Slime renderer reused for the custom assistant ball with a generated yellow face texture. */
@SuppressWarnings({"rawtypes", "unchecked"})
public final class RoundBallEntityRenderer extends class_945 {
    private static final class_2960 TEXTURE = class_2960.method_60655(RoundBallAssistant.MOD_ID, "textures/entity/round_ball.png");

    public RoundBallEntityRenderer(class_5617.class_5618 context) {
        super(context);
        this.field_4673 = 0.25f;
    }

    @Override
    public class_2960 method_4116(class_1621 entity) { return TEXTURE; }
}
