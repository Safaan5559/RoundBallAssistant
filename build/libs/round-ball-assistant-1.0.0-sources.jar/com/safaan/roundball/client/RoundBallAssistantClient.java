package com.safaan.roundball.client;

import com.safaan.roundball.AssistantService;
import com.safaan.roundball.RoundBallAssistant;
import com.safaan.roundball.entity.ModEntities;
import com.safaan.roundball.entity.RoundBallEntity;
import com.safaan.roundball.voice.AndroidVoiceAdapter;
import com.safaan.roundball.voice.DesktopVoiceAdapter;
import com.safaan.roundball.voice.OnlineVoiceConfig;
import com.safaan.roundball.voice.OnlineVoiceProvider;
import com.safaan.roundball.voice.VoiceInputProvider;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.class_2561;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

/** Client entry point: GUI, keybinds, entity rendering and toggle voice commands. */
@SuppressWarnings({"rawtypes", "unchecked"})
public final class RoundBallAssistantClient implements ClientModInitializer {
    private static class_304 openAssistant;
    private static class_304 pushToTalk;
    private static DesktopVoiceAdapter desktopVoice;
    private static AndroidVoiceAdapter androidVoice;
    private static OnlineVoiceProvider voiceProvider;
    private static final AssistantService ASSISTANT = new AssistantService();
    private static boolean voiceToggle;

    @Override
    public void onInitializeClient() {
        openAssistant = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.roundballassistant.open", class_3675.class_307.field_1668, GLFW.GLFW_KEY_K,
                "category.roundballassistant"));
        pushToTalk = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.roundballassistant.push_to_talk", class_3675.class_307.field_1668, GLFW.GLFW_KEY_V,
                "category.roundballassistant"));
        EntityRendererRegistry.register(ModEntities.ROUND_BALL,
                ctx -> (net.minecraft.class_897) new RoundBallEntityRenderer(ctx));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openAssistant.method_1436()) {
                if (client.field_1724 != null && hasShiftDown()) client.method_1507(new AssistantScreen());
            }
            while (pushToTalk.method_1436()) {
                voiceToggle = !voiceToggle;
                if (voiceToggle) {
                    ensureVoice();
                    if (!voiceRunning()) startVoice(client);
                } else {
                    stopVoice();
                }
                if (client.field_1724 != null) {
                    client.field_1724.method_7353(class_2561.method_43470(voiceToggle ? "Voice: ON" : "Voice: OFF"), true);
                }
            }
        });
        RoundBallAssistant.LOGGER.info("Round Ball Assistant client initialized");
    }

    private static void ensureVoice() {
        if (voiceProvider != null) return;
        OnlineVoiceConfig config = VoiceSettingsScreen.voiceConfig();
        voiceProvider = new OnlineVoiceProvider(config);
        if (isAndroidRuntime()) androidVoice = new AndroidVoiceAdapter(voiceProvider);
        else desktopVoice = new DesktopVoiceAdapter(voiceProvider);
    }

    private static boolean isAndroidRuntime() {
        try {
            Class.forName("android.os.Build", false, RoundBallAssistantClient.class.getClassLoader());
            return true;
        } catch (Throwable ignored) {
            return false;
        }
    }

    private static boolean voiceRunning() {
        return desktopVoice != null ? desktopVoice.isRunning()
                : androidVoice != null && androidVoice.isRunning();
    }

    private static void startVoice(class_310 client) {
        VoiceInputProvider.Listener listener = new VoiceInputProvider.Listener() {
            @Override
            public void onTranscript(String message) {
                if (message == null || message.isBlank() || !voiceToggle) return;
                client.execute(() -> processVoiceCommand(client, message.trim()));
            }

            @Override
            public void onError(String message) {
                if (client.field_1724 != null && message != null && !message.isBlank()) {
                    client.execute(() -> client.field_1724.method_7353(
                            class_2561.method_43470("[Voice] " + message), false));
                }
            }
        };
        if (desktopVoice != null) desktopVoice.start(listener);
        else if (androidVoice != null) androidVoice.start(listener);
    }

    private static void processVoiceCommand(class_310 client, String transcript) {
        if (client.field_1724 == null || client.field_1687 == null) return;
        RoundBallEntity ball = client.field_1687.method_8390(
                RoundBallEntity.class,
                client.field_1724.method_5829().method_1014(32.0),
                entity -> entity.method_5805())
                .stream()
                .min((a, b) -> Double.compare(
                        client.field_1724.method_5858(a), client.field_1724.method_5858(b)))
                .orElse(null);

        client.field_1724.method_7353(class_2561.method_43470("You: " + transcript), false);
        ASSISTANT.handle(client.field_1724, ball, transcript, reply -> {
            String spokenReply = reply == null || reply.isBlank() ? "I'm ready." : reply;
            client.field_1724.method_7353(class_2561.method_43470("Round Ball: " + spokenReply), false);
            if (voiceProvider != null) voiceProvider.speak(spokenReply);
        });
    }

    private static void stopVoice() {
        if (desktopVoice != null) desktopVoice.stop();
        if (androidVoice != null) androidVoice.stop();
    }

    private static boolean hasShiftDown() {
        long handle = class_310.method_1551().method_22683().method_4490();
        return class_3675.method_15987(handle, GLFW.GLFW_KEY_LEFT_SHIFT)
                || class_3675.method_15987(handle, GLFW.GLFW_KEY_RIGHT_SHIFT);
    }
}
