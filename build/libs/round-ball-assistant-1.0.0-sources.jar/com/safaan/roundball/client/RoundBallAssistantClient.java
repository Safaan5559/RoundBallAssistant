package com.safaan.roundball.client;

import com.safaan.roundball.RoundBallAssistant;
import com.safaan.roundball.entity.ModEntities;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

/** Client entry point: GUI, keybinds and custom entity rendering. */
@SuppressWarnings({"rawtypes", "unchecked"})
public final class RoundBallAssistantClient implements ClientModInitializer {
    private static class_304 openAssistant;

    @Override
    public void onInitializeClient() {
        openAssistant = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.roundballassistant.open", class_3675.class_307.field_1668, GLFW.GLFW_KEY_K,
                "category.roundballassistant"));

        EntityRendererRegistry.register(ModEntities.ROUND_BALL, ctx -> (net.minecraft.class_897) new RoundBallEntityRenderer(ctx));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openAssistant.method_1436()) {
                if (client.field_1724 != null && hasShiftDown()) client.method_1507(new AssistantScreen());
            }
        });
        RoundBallAssistant.LOGGER.info("Round Ball Assistant client initialized");
    }

    private static boolean hasShiftDown() {
        long handle = net.minecraft.class_310.method_1551().method_22683().method_4490();
        return class_3675.method_15987(handle, GLFW.GLFW_KEY_LEFT_SHIFT)
                || class_3675.method_15987(handle, GLFW.GLFW_KEY_RIGHT_SHIFT);
    }
}
