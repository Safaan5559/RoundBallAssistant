package com.safaan.roundball.client;

import com.safaan.roundball.config.AssistantConfig;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;

/** Client settings for direct voice conversations. */
public final class VoiceSettingsScreen extends class_437 {
    private final class_437 parent;
    private static final AssistantConfig CONFIG = new AssistantConfig();

    public VoiceSettingsScreen(class_437 parent) {
        super(class_2561.method_43470("Round Ball Voice Settings"));
        this.parent = parent;
    }

    public static AssistantConfig config() { return CONFIG; }

    @Override
    protected void method_25426() {
        int w = 300;
        int x = (field_22789 - w) / 2;
        method_37063(class_4185.method_46430(class_2561.method_43470("Voice Conversations: " + (CONFIG.voiceConversations() ? "ON" : "OFF")), b -> {
            CONFIG.setVoiceConversations(!CONFIG.voiceConversations());
            b.method_25355(class_2561.method_43470("Voice Conversations: " + (CONFIG.voiceConversations() ? "ON" : "OFF")));
        }).method_46434(x, field_22790 / 2 - 35, w, 20).method_46431());
        method_37063(class_4185.method_46430(class_2561.method_43470("Push-to-talk: " + (CONFIG.pushToTalk() ? "ON" : "OFF")), b -> {
            CONFIG.setPushToTalk(!CONFIG.pushToTalk());
            b.method_25355(class_2561.method_43470("Push-to-talk: " + (CONFIG.pushToTalk() ? "ON" : "OFF")));
        }).method_46434(x, field_22790 / 2 - 8, w, 20).method_46431());
        method_37063(class_4185.method_46430(class_2561.method_43470("Done"), b -> method_25419()).method_46434(x, field_22790 / 2 + 35, w, 20).method_46431());
    }

    @Override
    public void method_25419() { if (field_22787 != null) field_22787.method_1507(parent); }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        method_25420(context, mouseX, mouseY, delta);
        context.method_27534(field_22793, field_22785, field_22789 / 2, field_22790 / 2 - 70, 0xFFFFFF);
        context.method_27534(field_22793,
                class_2561.method_43470("When enabled, voice mode can use direct speech without opening Shift+K."), field_22789 / 2, field_22790 / 2 + 65, 0xAAAAAA);
        super.method_25394(context, mouseX, mouseY, delta);
    }

    @Override public boolean method_25421() { return false; }
}
