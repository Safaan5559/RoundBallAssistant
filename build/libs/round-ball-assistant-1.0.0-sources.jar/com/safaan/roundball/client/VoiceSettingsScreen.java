package com.safaan.roundball.client;

import com.safaan.roundball.config.AssistantConfig;
import com.safaan.roundball.voice.OnlineVoiceConfig;
import com.safaan.roundball.voice.VoiceConfigStore;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;

/** Client settings for direct voice conversations and Fish Audio TTS. */
public final class VoiceSettingsScreen extends class_437 {
    private final class_437 parent;
    private static final AssistantConfig CONFIG = new AssistantConfig();
    private static final OnlineVoiceConfig VOICE = new OnlineVoiceConfig();
    private class_342 apiKey;
    private class_342 voiceId;

    static {
        VoiceConfigStore.load(VOICE);
    }

    public VoiceSettingsScreen(class_437 parent) {
        super(class_2561.method_43470("Round Ball Voice Settings"));
        this.parent = parent;
    }

    public static AssistantConfig config() { return CONFIG; }
    public static OnlineVoiceConfig voiceConfig() { return VOICE; }

    @Override
    protected void method_25426() {
        int w = 320;
        int x = (field_22789 - w) / 2;
        int y = Math.max(20, field_22790 / 2 - 95);

        method_37063(class_4185.method_46430(class_2561.method_43470("Voice Conversations: " + (CONFIG.voiceConversations() ? "ON" : "OFF")), b -> {
            CONFIG.setVoiceConversations(!CONFIG.voiceConversations());
            b.method_25355(class_2561.method_43470("Voice Conversations: " + (CONFIG.voiceConversations() ? "ON" : "OFF")));
        }).method_46434(x, y, w, 20).method_46431());

        method_37063(class_4185.method_46430(class_2561.method_43470("Push-to-talk: " + (CONFIG.pushToTalk() ? "ON" : "OFF")), b -> {
            CONFIG.setPushToTalk(!CONFIG.pushToTalk());
            b.method_25355(class_2561.method_43470("Push-to-talk: " + (CONFIG.pushToTalk() ? "ON" : "OFF")));
        }).method_46434(x, y + 25, w, 20).method_46431());

        apiKey = new class_342(field_22793, x, y + 58, w, 20, class_2561.method_43470("Fish Audio API key"));
        apiKey.method_1880(512);
        apiKey.method_1852(VOICE.apiKey());
        apiKey.method_1854((text, offset) -> class_2561.method_43470("•".repeat(Math.max(0, text.length() - offset))).method_30937());
        method_37063(apiKey);

        voiceId = new class_342(field_22793, x, y + 85, w, 20, class_2561.method_43470("Verity voice/reference ID"));
        voiceId.method_1880(256);
        voiceId.method_1852(VOICE.voice());
        method_37063(voiceId);

        method_37063(class_4185.method_46430(class_2561.method_43470("Fish Audio TTS: " + (VOICE.enabled() ? "ON" : "OFF")), b -> {
            VOICE.setEnabled(!VOICE.enabled());
            b.method_25355(class_2561.method_43470("Fish Audio TTS: " + (VOICE.enabled() ? "ON" : "OFF")));
        }).method_46434(x, y + 112, w, 20).method_46431());

        method_37063(class_4185.method_46430(class_2561.method_43470("Save & Done"), b -> {
            VOICE.setApiKey(apiKey.method_1882().trim());
            VOICE.setVoice(voiceId.method_1882().trim());
            VoiceConfigStore.save(VOICE);
            method_25419();
        }).method_46434(x, y + 145, w, 20).method_46431());
    }

    @Override
    public void method_25419() { if (field_22787 != null) field_22787.method_1507(parent); }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        method_25420(context, mouseX, mouseY, delta);
        context.method_27534(field_22793, field_22785, field_22789 / 2, Math.max(8, field_22790 / 2 - 125), 0xFFFFFF);
        context.method_27534(field_22793, class_2561.method_43470("Fish Audio • Verity voice"), field_22789 / 2, Math.max(18, field_22790 / 2 - 108), 0xAAAAAA);
        super.method_25394(context, mouseX, mouseY, delta);
    }

    @Override public boolean method_25421() { return false; }
}
