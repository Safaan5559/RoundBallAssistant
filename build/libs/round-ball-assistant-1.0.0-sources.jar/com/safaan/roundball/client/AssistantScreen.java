package com.safaan.roundball.client;

import com.safaan.roundball.AssistantService;
import com.safaan.roundball.entity.RoundBallEntity;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;

/** Text interface. The same AssistantService is used by the voice architecture. */
public final class AssistantScreen extends class_437 {
    private final AssistantService service = new AssistantService();
    private class_342 input;
    private String lastReply = "Ask me anything about what I can do.";

    public AssistantScreen() { super(class_2561.method_43470("Round Ball Assistant")); }

    @Override
    protected void method_25426() {
        int width = Math.min(360, this.field_22789 - 30);
        int x = (this.field_22789 - width) / 2;
        this.input = new class_342(this.field_22793, x, this.field_22790 / 2 - 8, width, 20, class_2561.method_43470("Ask the ball"));
        this.input.method_1880(512);
        this.method_37063(input);
        this.method_37063(class_4185.method_46430(class_2561.method_43470("Send"), button -> submit())
                .method_46434(x, this.field_22790 / 2 + 20, width, 20).method_46431());
        this.method_37063(class_4185.method_46430(class_2561.method_43470("Voice settings"), button -> this.field_22787.method_1507(new VoiceSettingsScreen(this)))
                .method_46434(x, this.field_22790 / 2 + 46, width, 20).method_46431());
        this.method_48265(input);
    }

    private void submit() {
        if (field_22787 == null || field_22787.field_1724 == null) return;
        String command = input.method_1882().trim();
        if (command.isEmpty()) return;
        RoundBallEntity ball = field_22787.field_1687.method_8390(RoundBallEntity.class,
                field_22787.field_1724.method_5829().method_1014(32), e -> true).stream().findFirst().orElse(null);
        service.handle(field_22787.field_1724, ball, command, reply -> lastReply = reply);
        field_22787.field_1724.method_7353(class_2561.method_43470("Round Ball: " + lastReply), false);
        input.method_1852("");
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        this.method_25420(context, mouseX, mouseY, delta);
        context.method_27534(this.field_22793, this.field_22785, field_22789 / 2, field_22790 / 2 - 50, 0xFFFFFF);
        context.method_27534(this.field_22793, class_2561.method_43470(lastReply), field_22789 / 2, field_22790 / 2 - 30, 0xFFFF55);
        super.method_25394(context, mouseX, mouseY, delta);
    }

    @Override public boolean method_25421() { return false; }
}
