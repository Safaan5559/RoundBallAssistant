package com.safaan.roundball;

import com.safaan.roundball.action.ActionManager;
import com.safaan.roundball.action.ActionResult;
import com.safaan.roundball.conversation.CommandInterpreter;
import com.safaan.roundball.conversation.Intent;
import com.safaan.roundball.entity.RoundBallEntity;
import java.util.function.Consumer;
import net.minecraft.class_1657;

/** Single service used by both typed commands and future voice transcripts. */
public final class AssistantService {
    private final CommandInterpreter interpreter = new CommandInterpreter();

    public ActionResult handle(class_1657 player, RoundBallEntity ball, String input, Consumer<String> response) {
        Intent intent = interpreter.interpret(input);
        ActionResult result = ActionManager.execute(player, ball, intent);
        response.accept(result.message());
        return result;
    }
}
