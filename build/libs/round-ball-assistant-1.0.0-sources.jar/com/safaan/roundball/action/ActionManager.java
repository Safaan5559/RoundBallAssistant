package com.safaan.roundball.action;

import com.safaan.roundball.conversation.Intent;
import com.safaan.roundball.entity.RoundBallEntity;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

/** Executes the deterministic in-game actions understood by the assistant. */
public final class ActionManager {
    private ActionManager() {}

    public static ActionResult execute(class_1657 player, RoundBallEntity ball, Intent intent) {
        return switch (intent.type()) {
            case GIVE_ITEM -> giveItem(player, intent.argument(), intent.amount());
            case FOLLOW -> { if (ball != null) ball.setController(player); yield ActionResult.ok("Okay, I'll follow you."); }
            case ATTACK -> { if (ball != null) ball.attackNearestHostile(); yield ActionResult.ok("I'll handle the nearby target."); }
            case STOP -> { if (ball != null) ball.method_5942().method_6340(); yield ActionResult.ok("Stopped my current movement."); }
            case FIND -> ActionResult.ok("Searching for " + (intent.argument().isBlank() ? "that" : intent.argument()) + ".");
            default -> ActionResult.ok("I'm ready.");
        };
    }

    private static ActionResult giveItem(class_1657 player, String name, int amount) {
        if (name == null || name.isBlank()) return ActionResult.fail("Tell me which item you want.");
        class_1792 item = class_7923.field_41178.method_10223(class_2960.method_60655("minecraft", name));
        if (item == null) return ActionResult.fail("I don't know that item.");
        class_1799 stack = new class_1799(item, Math.max(1, Math.min(64, amount)));
        boolean inserted = player.method_31548().method_7394(stack);
        if (!inserted && !stack.method_7960()) {
            player.method_7328(stack, false);
        }
        return ActionResult.ok("Here is " + name.replace('_', ' ') + ".");
    }
}
