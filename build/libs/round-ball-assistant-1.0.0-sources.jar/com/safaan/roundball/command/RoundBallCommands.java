package com.safaan.roundball.command;

import com.mojang.brigadier.CommandDispatcher;
import com.safaan.roundball.entity.ModEntities;
import com.safaan.roundball.entity.RoundBallEntity;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2561;

/** Server commands for spawning and managing the companion. */
public final class RoundBallCommands {
    private RoundBallCommands() {}

    public static void register() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> register(dispatcher));
    }

    private static void register(CommandDispatcher<class_2168> dispatcher) {
        dispatcher.register(class_2170.method_9247("roundball")
                .then(class_2170.method_9247("summon").executes(ctx -> summon(ctx.getSource())))
                .then(class_2170.method_9247("help").executes(ctx -> {
                    ctx.getSource().method_9226(() -> class_2561.method_43470("Round Ball: /roundball summon"), false);
                    return 1;
                })));
    }

    private static int summon(class_2168 source) {
        var player = source.method_44023();
        if (player == null) return 0;
        RoundBallEntity ball = ModEntities.ROUND_BALL.method_5883(player.method_37908());
        if (ball == null) return 0;
        ball.method_5808(player.method_23317() + 1.0, player.method_23318(), player.method_23321(), player.method_36454(), 0);
        ball.setController(player);
        player.method_37908().method_8649(ball);
        source.method_9226(() -> class_2561.method_43470("Round Ball joined you!"), false);
        return 1;
    }
}
